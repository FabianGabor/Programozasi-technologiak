package eretts2018;

import java.io.IOException;
import java.io.RandomAccessFile;

public class Beolvasás
{
    public static void main(String[] args)
    {
        // 1. feladat
        Mozgás[] mozgások = null;

        try
        {
            RandomAccessFile raf = new RandomAccessFile("ajto.txt","r");
            String sor;
            int db = 0;
            for( sor = raf.readLine(); sor != null; sor = raf.readLine() )
            {
                db++;
                System.out.println(db);
            }

            mozgások = new Mozgás[db];
            raf.seek(0);
            db = 0;
            for( sor = raf.readLine(); sor != null; sor = raf.readLine() )
            {
                mozgások[db] = new Mozgás(sor.split(" "));
                db++;
            }
            raf.close();
        }
        catch( IOException e )
        {
            System.out.println("HIBA");
        }

    for( Mozgás e : mozgások )
    {
      System.out.println(e);
    }

    }
}